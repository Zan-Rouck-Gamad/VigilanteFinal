package com.validate;
import java.sql.*;

public class Validate
 {
     public static boolean checkUser(String idnumber,String password) 
     {
      boolean st =false;
      try{

	 //loading drivers for mysql
         Class.forName("com.mysql.jdbc.Driver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection
                        ("jdbc:mysql:/ /localhost:3306/canteen","root","");
         PreparedStatement ps =con.prepareStatement
                             ("select * from student where idnumber=? and password=?");
         ps.setString(1, idnumber);
         ps.setString(2, password);
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(Exception e)
      {
          e.printStackTrace();
      }
         return st;                 
  }   
}