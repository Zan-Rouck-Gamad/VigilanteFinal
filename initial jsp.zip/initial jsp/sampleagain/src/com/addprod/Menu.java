package com.addprod;
 
public class Menu {
    private String title;
    private String price;
    private String description;
     
    private byte[] image;  
 
   
   
    private String base64Image;
     
    public String getBase64Image() {
        return base64Image;
    }
 
    public void setBase64Image(String base64Image) {
        this.base64Image = base64Image;
    }
    public String getTitle() {
        return title;
    }
    

	public void setTitle(String title) {
		// TODO Auto-generated method stub
		
	}
	 public String getPrice() {
	        return getPrice();
	    }

	public void setPrice(String price) {
		// TODO Auto-generated method stub
		
	}
	

	public void setDescription(String description) {
		// TODO Auto-generated method stub
		
	}
	
	 public String getDescription() {
	        return getDescription();
	    }
 
 
    // other fields...
    // other getters and setters
}